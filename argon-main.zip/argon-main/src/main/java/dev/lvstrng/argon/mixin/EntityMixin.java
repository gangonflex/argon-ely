package dev.lvstrng.argon.mixin;

import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.module.modules.combat.StaticHitboxes;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public class EntityMixin {
	
	@Inject(method = "getDimensions", at = @At("HEAD"), cancellable = true)
	private void onGetDimensions(EntityPose pose, CallbackInfoReturnable<EntityDimensions> cir) {
		StaticHitboxes staticHitboxes = Argon.INSTANCE.getModuleManager().getModule(StaticHitboxes.class);
		if (staticHitboxes != null && staticHitboxes.isEnabled()) {
			// If entity is in fall flying pose (elytra), return standing dimensions instead
			if (pose == EntityPose.FALL_FLYING) {
				LivingEntity entity = (LivingEntity) (Object) this;
				cir.setReturnValue(entity.getDimensions(EntityPose.STANDING));
			}
		}
	}
}
