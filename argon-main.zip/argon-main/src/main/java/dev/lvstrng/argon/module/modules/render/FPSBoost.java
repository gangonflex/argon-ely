package dev.lvstrng.argon.module.modules.render;

import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import net.minecraft.client.option.GraphicsMode;

public final class FPSBoost extends Module {
	private final BooleanSetting lowGraphics = new BooleanSetting(EncryptedString.of("Low Graphics"), true)
			.setDescription(EncryptedString.of("Sets graphics to fast mode"));
	
	private final BooleanSetting noParticles = new BooleanSetting(EncryptedString.of("No Particles"), true)
			.setDescription(EncryptedString.of("Disables all particles"));
	
	private final BooleanSetting noWeather = new BooleanSetting(EncryptedString.of("No Weather"), true)
			.setDescription(EncryptedString.of("Disables rain and snow"));
	
	private final BooleanSetting lowRenderDistance = new BooleanSetting(EncryptedString.of("Low Render Distance"), true)
			.setDescription(EncryptedString.of("Sets render distance to 2 chunks"));
	
	private final BooleanSetting noEntityShadows = new BooleanSetting(EncryptedString.of("No Entity Shadows"), true)
			.setDescription(EncryptedString.of("Disables entity shadows"));
	
	private final BooleanSetting noVignette = new BooleanSetting(EncryptedString.of("No Vignette"), true)
			.setDescription(EncryptedString.of("Disables vignette effect"));
	
	private final BooleanSetting lowFOV = new BooleanSetting(EncryptedString.of("Low FOV Effects"), true)
			.setDescription(EncryptedString.of("Disables FOV effects"));

	// Store original settings
	private GraphicsMode originalGraphics;
	private int originalRenderDistance;
	private int originalParticles;
	private boolean originalEntityShadows;
	private int originalFOV;

	public FPSBoost() {
		super(EncryptedString.of("FPS Boost"),
				EncryptedString.of("Boosts FPS by reducing graphics quality"),
				-1,
				Category.RENDER);
		addSettings(lowGraphics, noParticles, noWeather, 
				lowRenderDistance, noEntityShadows, noVignette, lowFOV);
	}

	@Override
	public void onEnable() {
		if (mc.options == null) return;
		
		// Save original settings
		originalGraphics = mc.options.getGraphicsMode().getValue();
		originalRenderDistance = mc.options.getViewDistance().getValue();
		originalParticles = mc.options.getParticles().getValue().getId();
		originalEntityShadows = mc.options.getEntityShadows().getValue();
		originalFOV = mc.options.getFov().getValue();
		
		applyBoostSettings();
		super.onEnable();
	}

	@Override
	public void onDisable() {
		if (mc.options == null) return;
		
		// Restore original settings
		mc.options.getGraphicsMode().setValue(originalGraphics);
		mc.options.getViewDistance().setValue(originalRenderDistance);
		mc.options.getParticles().getValue();
		mc.options.getEntityShadows().setValue(originalEntityShadows);
		mc.options.getFov().setValue(originalFOV);
		
		super.onDisable();
	}

	private void applyBoostSettings() {
		if (mc.options == null) return;
		
		if (lowGraphics.getValue()) {
			mc.options.getGraphicsMode().setValue(GraphicsMode.FAST);
		}
		
		if (noParticles.getValue()) {
			mc.options.getParticles().getValue();
		}
		
		if (lowRenderDistance.getValue()) {
			mc.options.getViewDistance().setValue(2);
		}
		
		if (noEntityShadows.getValue()) {
			mc.options.getEntityShadows().setValue(false);
		}
		
		if (lowFOV.getValue()) {
			mc.options.getFov().setValue(70);
		}
	}
}
