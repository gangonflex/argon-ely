package dev.lvstrng.argon.module.modules.render;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.lvstrng.argon.event.events.GameRenderListener;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.RenderUtils;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.List;

public final class SkeletonESP extends Module implements GameRenderListener {
	private final BooleanSetting distanceColors = new BooleanSetting(EncryptedString.of("Distance Colors"), false)
			.setDescription(EncryptedString.of("Change skeleton color based on distance"));
	
	private final NumberSetting red = new NumberSetting(EncryptedString.of("Red"), 0, 255, 255, 1);
	private final NumberSetting green = new NumberSetting(EncryptedString.of("Green"), 0, 255, 255, 1);
	private final NumberSetting blue = new NumberSetting(EncryptedString.of("Blue"), 0, 255, 255, 1);
	private final NumberSetting alpha = new NumberSetting(EncryptedString.of("Alpha"), 0, 255, 255, 1);
	
	private final NumberSetting verticalOffset = new NumberSetting(EncryptedString.of("Vertical Offset"), 1.0, 1.6, 1.35, 0.01)
			.setDescription(EncryptedString.of("Fixed vertical offset for skeleton placement"));
	
	private final NumberSetting forwardOffset = new NumberSetting(EncryptedString.of("Forward Offset"), -0.3, 0.3, 0.0, 0.01)
			.setDescription(EncryptedString.of("Forward/back offset of skeleton from chest center"));
	
	private final NumberSetting horizontalOffset = new NumberSetting(EncryptedString.of("Horizontal Offset"), 0.0, 0.5, 0.25, 0.01)
			.setDescription(EncryptedString.of("Horizontal width of shoulders/arms"));
	
	private final NumberSetting lineWidth = new NumberSetting(EncryptedString.of("Line Width"), 1, 5, 2, 1);

	public SkeletonESP() {
		super(EncryptedString.of("Skeleton ESP"),
				EncryptedString.of("Renders player skeletons with correct offsets & rotation"),
				-1,
				Category.RENDER);
		addSettings(distanceColors, red, green, blue, alpha, verticalOffset, forwardOffset, horizontalOffset, lineWidth);
	}

	@Override
	public void onEnable() {
		eventManager.add(GameRenderListener.class, this);
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(GameRenderListener.class, this);
		super.onDisable();
	}

	@Override
	public void onGameRender(GameRenderEvent event) {
		if (mc.player == null || mc.world == null) return;

		List<AbstractClientPlayerEntity> players = mc.world.getPlayers();
		
		var cam = mc.getBlockEntityRenderDispatcher().camera;
		Vec3d camPos = cam.getPos();
		
		event.matrices.push();
		event.matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_X.rotationDegrees(cam.getPitch()));
		event.matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Y.rotationDegrees(cam.getYaw() + 180F));
		
		for (AbstractClientPlayerEntity player : players) {
			// Skip self in first-person
			if (mc.options.getPerspective() == Perspective.FIRST_PERSON && player == mc.player) continue;

			Vec3d basePos = player.getLerpedPos(RenderTickCounter.ONE.getTickDelta(true)).subtract(camPos);
			Color skeletonColor = distanceColors.getValue() ? getColorFromDistance(player.getLerpedPos(RenderTickCounter.ONE.getTickDelta(true))) : 
					new Color(red.getValueInt(), green.getValueInt(), blue.getValueInt(), alpha.getValueInt());

			// Rotation
			double yawRad = Math.toRadians(-player.bodyYaw);

			// Base chest position with fixed vertical offset
			Vec3d chestBase = basePos.add(0, verticalOffset.getValue(), 0);
			if (player.isSneaking()) {
				chestBase = chestBase.add(0, -0.2, 0);
			}

			// Apply forward offset rotated with player
			Vec3d forwardVec = new Vec3d(0, 0, forwardOffset.getValue()).rotateY((float) yawRad);
			chestBase = chestBase.add(forwardVec);

			// Shoulder positions
			Vec3d leftShoulder = chestBase.add(new Vec3d(-horizontalOffset.getValue(), 0, 0).rotateY((float) yawRad));
			Vec3d rightShoulder = chestBase.add(new Vec3d(horizontalOffset.getValue(), 0, 0).rotateY((float) yawRad));

			// Arm endpoints
			Vec3d leftArmEnd = leftShoulder.add(0, -0.6, 0);
			Vec3d rightArmEnd = rightShoulder.add(0, -0.6, 0);

			// Spine start (hips)
			Vec3d spineStart = basePos.add(forwardVec);

			// Spine end (shoulder center)
			Vec3d spineEnd = chestBase;

			// Head
			Vec3d headTop = chestBase.add(0, 0.25, 0);

			// Draw skeleton
			drawLineSimple(event.matrices, spineStart, spineEnd, skeletonColor);
			drawLineSimple(event.matrices, leftShoulder, rightShoulder, skeletonColor);
			drawLineSimple(event.matrices, leftShoulder, leftArmEnd, skeletonColor);
			drawLineSimple(event.matrices, rightShoulder, rightArmEnd, skeletonColor);
			drawLineSimple(event.matrices, spineEnd, headTop, skeletonColor);
		}
		
		event.matrices.pop();
	}

	private void drawLineSimple(MatrixStack matrices, Vec3d start, Vec3d end, Color color) {
		Matrix4f matrix = matrices.peek().getPositionMatrix();
		
		RenderSystem.setShader(GameRenderer::getPositionColorProgram);
		RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
		RenderSystem.defaultBlendFunc();
		RenderSystem.enableBlend();
		GL11.glDepthFunc(GL11.GL_ALWAYS);
		GL11.glLineWidth(lineWidth.getValueFloat());
		
		BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
		
		buffer.vertex(matrix, (float) start.x, (float) start.y, (float) start.z)
				.color(color.getRed() / 255f, color.getGreen() / 255f, color.getBlue() / 255f, color.getAlpha() / 255f);
		buffer.vertex(matrix, (float) end.x, (float) end.y, (float) end.z)
				.color(color.getRed() / 255f, color.getGreen() / 255f, color.getBlue() / 255f, color.getAlpha() / 255f);
		
		BufferRenderer.drawWithGlobalProgram(buffer.end());
		
		GL11.glDepthFunc(GL11.GL_LEQUAL);
		GL11.glLineWidth(1f);
		RenderSystem.disableBlend();
	}

	private void drawLine(MatrixStack matrices, Vec3d start, Vec3d end, Color color) {
		matrices.push();
		
		var cam = mc.getBlockEntityRenderDispatcher().camera;
		Vec3d camPos = cam.getPos();
		
		// Subtract camera position for proper world-space rendering
		start = start.subtract(camPos);
		end = end.subtract(camPos);
		
		// Apply camera rotation
		matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_X.rotationDegrees(cam.getPitch()));
		matrices.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Y.rotationDegrees(cam.getYaw() + 180F));
		
		Matrix4f matrix = matrices.peek().getPositionMatrix();
		
		RenderSystem.setShader(GameRenderer::getPositionColorProgram);
		RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
		RenderSystem.defaultBlendFunc();
		RenderSystem.enableBlend();
		GL11.glDepthFunc(GL11.GL_ALWAYS);
		GL11.glLineWidth(lineWidth.getValueFloat());
		
		BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
		
		buffer.vertex(matrix, (float) start.x, (float) start.y, (float) start.z)
				.color(color.getRed() / 255f, color.getGreen() / 255f, color.getBlue() / 255f, color.getAlpha() / 255f);
		buffer.vertex(matrix, (float) end.x, (float) end.y, (float) end.z)
				.color(color.getRed() / 255f, color.getGreen() / 255f, color.getBlue() / 255f, color.getAlpha() / 255f);
		
		BufferRenderer.drawWithGlobalProgram(buffer.end());
		
		GL11.glDepthFunc(GL11.GL_LEQUAL);
		GL11.glLineWidth(1f);
		RenderSystem.disableBlend();
		
		matrices.pop();
	}

	private Color getColorFromDistance(Vec3d pos) {
		double distance = mc.player.getPos().distanceTo(pos);
		double percent = Math.min(1.0, distance / 60.0);
		int r, g;

		// Reverse gradient: Green (close) → Yellow → Orange → Red (far)
		if (percent < 0.33) {
			// Green → Yellow
			r = (int)(percent / 0.33 * 255);
			g = 255;
		} else if (percent < 0.66) {
			// Yellow → Orange
			r = 255;
			g = 255 - (int)((percent - 0.33) / 0.33 * 90);
		} else {
			// Orange → Red
			r = 255;
			g = 165 - (int)((percent - 0.66) / 0.34 * 165);
		}

		return new Color(r, g, 0, alpha.getValueInt());
	}
}
