package dev.lvstrng.argon.module.modules.combat;

import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.utils.EncryptedString;

public final class StaticHitboxes extends Module {

	public StaticHitboxes() {
		super(EncryptedString.of("Static Hitboxes"),
				EncryptedString.of("Prevents hitbox height from changing when entities use elytra"),
				-1,
				Category.COMBAT);
	}

	@Override
	public void onEnable() {
		super.onEnable();
	}

	@Override
	public void onDisable() {
		super.onDisable();
	}
}
