package dev.lvstrng.argon.module.modules.render;

import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.event.events.HudListener;
import dev.lvstrng.argon.gui.ClickGui;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.modules.client.ClickGUI;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.ModeSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.RenderUtils;
import dev.lvstrng.argon.utils.TextRenderer;
import dev.lvstrng.argon.utils.Utils;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;

import java.awt.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class HUD extends Module implements HudListener {
	private final BooleanSetting watermark = new BooleanSetting(EncryptedString.of("Watermark"), true);
	private final BooleanSetting arraylist = new BooleanSetting(EncryptedString.of("Arraylist"), true);
	private final BooleanSetting background = new BooleanSetting(EncryptedString.of("Background"), true);
	private final NumberSetting bgOpacity = new NumberSetting(EncryptedString.of("BG Opacity"), 0, 255, 120, 5);
	private final BooleanSetting glow = new BooleanSetting(EncryptedString.of("Glow"), true);
	
	private final Map<Module, Float> moduleAnimations = new HashMap<>();

	public HUD() {
		super(EncryptedString.of("HUD"),
				EncryptedString.of("Renders the client version and enabled modules on the HUD"),
				-1,
				Category.RENDER);
		addSettings(watermark, arraylist, background, bgOpacity, glow);
	}

	@Override
	public void onEnable() {
		eventManager.add(HudListener.class, this);
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(HudListener.class, this);
		super.onDisable();
	}

	@Override
	public void onRenderHud(HudEvent event) {
		if (mc.currentScreen != Argon.INSTANCE.clickGui) {
			final List<Module> enabledModules = Argon.INSTANCE.
					getModuleManager().
					getEnabledModules().
					stream().
					sorted((module1, module2) -> {
						CharSequence name1 = module1.getName();
						CharSequence name2 = module2.getName();

						int filteredLength1 = TextRenderer.getWidth(name1);
						int filteredLength2 = TextRenderer.getWidth(name2);

						return Integer.compare(filteredLength2, filteredLength1);
					}).
					toList();

			DrawContext context = event.context;
			boolean customFont = ClickGUI.customFont.getValue();

			if (!(mc.currentScreen instanceof ClickGui)) {

				if (watermark.getValue() && mc.player != null) {
					RenderUtils.unscaledProjection();
					
					context.getMatrices().push();
					context.getMatrices().scale(1.5f, 1.5f, 1.5f);
					
					TextRenderer.drawString("Argon", context, 7, 8, Utils.getMainColor(255, 1).getRGB());
					
					context.getMatrices().pop();
					RenderUtils.scaledProjection();
				}
				
				if (arraylist.getValue()) {
					int offset = 55;
					Color arrayBg = new Color(0, 0, 0, bgOpacity.getValueInt());
					
					for (Module module : enabledModules) {
						if (!moduleAnimations.containsKey(module)) {
							moduleAnimations.put(module, 0f);
						}
						
						float currentAnim = moduleAnimations.get(module);
						currentAnim += (1f - currentAnim) * 0.15f;
						moduleAnimations.put(module, currentAnim);
						
						RenderUtils.unscaledProjection();
						int charOffset = 6 + TextRenderer.getWidth(module.getName());
						int slideOffset = (int) ((1f - currentAnim) * -50);

						if (glow.getValue() && background.getValue()) {
							Color glowColor = new Color(0, 0, 0, (int)(0.4f * bgOpacity.getValueInt()));
							RenderUtils.renderRoundedQuad(context.getMatrices(), glowColor, 
									slideOffset - 2, offset - 6, 
									(charOffset + 7) + slideOffset, offset + (mc.textRenderer.fontHeight * 2) + 1, 
									0, 0, 0, 7, 12);
						}

						if (background.getValue()) {
							RenderUtils.renderRoundedQuad(context.getMatrices(), arrayBg, 
									slideOffset, offset - 4, 
									(charOffset + 5) + slideOffset, offset + (mc.textRenderer.fontHeight * 2) - 1, 
									0, 0, 0, 5, 10);
						}
						
						int gradientColor1 = Utils.getMainColor((int)(255 * currentAnim), (enabledModules.indexOf(module))).getRGB();
						int gradientColor2 = Utils.getMainColor((int)(255 * currentAnim), (enabledModules.indexOf(module)) + 1).getRGB();
						context.fillGradient(slideOffset, offset - 4, 
								2 + slideOffset, offset + (mc.textRenderer.fontHeight * 2), 
								gradientColor1, gradientColor2);

						int charOffset2 = customFont ? 5 : 8;
						int textColor = Utils.getMainColor((int)(255 * currentAnim), (enabledModules.indexOf(module))).getRGB();
						TextRenderer.drawString(module.getName(), context, 
								charOffset2 + slideOffset, 
								offset + (customFont ? 1 : 0), 
								textColor);

						offset += (mc.textRenderer.fontHeight * 2) + 3;
						RenderUtils.scaledProjection();
					}
					
					moduleAnimations.keySet().removeIf(module -> !enabledModules.contains(module));
				}
			}
		}
	}
}