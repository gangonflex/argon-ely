package dev.lvstrng.argon.module.modules.render;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.lvstrng.argon.event.events.GameRenderListener;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.modules.client.ClickGUI;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.ColorUtils;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.RenderUtils;
import dev.lvstrng.argon.utils.Utils;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import net.minecraft.util.math.RotationAxis;

import java.awt.*;

public final class PlayerESP extends Module implements GameRenderListener {
	private final NumberSetting red = new NumberSetting(EncryptedString.of("Red"), 0, 255, 255, 1);
	private final NumberSetting green = new NumberSetting(EncryptedString.of("Green"), 0, 255, 255, 1);
	private final NumberSetting blue = new NumberSetting(EncryptedString.of("Blue"), 0, 255, 255, 1);
	private final NumberSetting alpha = new NumberSetting(EncryptedString.of("Alpha"), 0, 255, 100, 1);
	private final NumberSetting width = new NumberSetting(EncryptedString.of("Line width"), 1, 10, 4, 1);
	private final BooleanSetting corners = new BooleanSetting(EncryptedString.of("Corners"), false)
			.setDescription(EncryptedString.of("Render only corners instead of full box"));
	private final BooleanSetting tracers = new BooleanSetting(EncryptedString.of("Tracers"), false)
			.setDescription(EncryptedString.of("Draws a line from your player to the other"));
	private final BooleanSetting healthBar = new BooleanSetting(EncryptedString.of("Health Bar"), true)
			.setDescription(EncryptedString.of("Shows health bar on left side of player"));

	public PlayerESP() {
		super(EncryptedString.of("Player ESP"),
				EncryptedString.of("Renders players through walls"),
				-1,
				Category.RENDER);
		addSettings(red, green, blue, alpha, width, corners, tracers, healthBar);
	}

	@Override
	public void onEnable() {
		eventManager.add(GameRenderListener.class, this);
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(GameRenderListener.class, this);
		super.onDisable();
	}

	@Override
	public void onGameRender(GameRenderEvent event) {
		for (PlayerEntity player : mc.world.getPlayers()) {
			if (player != mc.player) {
				var cam = mc.getBlockEntityRenderDispatcher().camera;
				event.matrices.push();
				event.matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(cam.getPitch()));
				event.matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(cam.getYaw() + 180F));
				
				if (corners.getValue()) {
					renderCorners(player, getColor(alpha.getValueInt()), event.matrices);
				} else {
					renderOutline(player, getColor(alpha.getValueInt()), event.matrices);
				}
				
				if (healthBar.getValue()) {
					renderHealthBar(player, event.matrices);
				}

				if (tracers.getValue())
					RenderUtils.renderLine(event.matrices, getColor(255), mc.crosshairTarget.getPos(), player.getLerpedPos(RenderTickCounter.ONE.getTickDelta(true)));

				event.matrices.pop();
			}
		}
	}

	private void renderOutline(PlayerEntity e, Color color, MatrixStack stack) {
		float red = color.brighter().getRed() / 255f;
		float green = color.brighter().getGreen() / 255f;
		float blue = color.brighter().getBlue() / 255f;
		float alpha = color.brighter().getAlpha() / 255f;

		Camera c = mc.gameRenderer.getCamera();
		Vec3d camPos = c.getPos();
		Vec3d start = e.getLerpedPos(RenderTickCounter.ONE.getTickDelta(true)).subtract(camPos);
		float x = (float) start.x;
		float y = (float) start.y;
		float z = (float) start.z;

		double r = Math.toRadians(-c.getYaw() + 90);
		float sin = (float) (Math.sin(r) * (e.getWidth() / 1.7));
		float cos = (float) (Math.cos(r) * (e.getWidth() / 1.7));
		stack.push();

		Matrix4f matrix = stack.peek().getPositionMatrix();

		RenderSystem.setShader(GameRenderer::getPositionColorProgram);
		if (ClickGUI.antiAliasing.getValue()) {
			GL11.glEnable(GL13.GL_MULTISAMPLE);
			GL11.glEnable(GL11.GL_LINE_SMOOTH);
			GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST);
		}
		GL11.glDepthFunc(GL11.GL_ALWAYS);
		RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
		RenderSystem.defaultBlendFunc();
		RenderSystem.enableBlend();

		GL11.glLineWidth(width.getValueInt());
		BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES,
				VertexFormats.POSITION_COLOR);

		buffer.vertex(matrix, x + sin, y, z + cos).color(red, green, blue, alpha);
		buffer.vertex(matrix, x - sin, y, z - cos).color(red, green, blue, alpha);
		buffer.vertex(matrix, x - sin, y, z - cos).color(red, green, blue, alpha);
		buffer.vertex(matrix, x - sin, y + e.getHeight(), z - cos).color(red, green, blue, alpha);
		buffer.vertex(matrix, x - sin, y + e.getHeight(), z - cos).color(red, green, blue, alpha);
		buffer.vertex(matrix, x + sin, y + e.getHeight(), z + cos).color(red, green, blue, alpha);
		buffer.vertex(matrix, x + sin, y + e.getHeight(), z + cos).color(red, green, blue, alpha);
		buffer.vertex(matrix, x + sin, y, z + cos).color(red, green, blue, alpha);
		buffer.vertex(matrix, x + sin, y, z + cos).color(red, green, blue, alpha);

		BufferRenderer.drawWithGlobalProgram(buffer.end());
		GL11.glDepthFunc(GL11.GL_LEQUAL);
		GL11.glLineWidth(1f);
		RenderSystem.disableBlend();
		if (ClickGUI.antiAliasing.getValue()) {
			GL11.glDisable(GL11.GL_LINE_SMOOTH);
			GL11.glDisable(GL13.GL_MULTISAMPLE);
		}
		stack.pop();
	}
	
	private void renderHealthBar(PlayerEntity player, MatrixStack stack) {
		Camera c = mc.gameRenderer.getCamera();
		Vec3d camPos = c.getPos();
		Vec3d start = player.getLerpedPos(RenderTickCounter.ONE.getTickDelta(true)).subtract(camPos);
		float x = (float) start.x;
		float y = (float) start.y;
		float z = (float) start.z;

		double r = Math.toRadians(-c.getYaw() + 90);
		float sin = (float) (Math.sin(r) * (player.getWidth() / 1.7));
		float cos = (float) (Math.cos(r) * (player.getWidth() / 1.7));
		
		float health = player.getHealth();
		float maxHealth = player.getMaxHealth();
		float healthPercentage = MathHelper.clamp(health / maxHealth, 0f, 1f);
		
		// Health bar colors with black background
		Color bgColor = new Color(0, 0, 0, 200);
		Color healthColor = getHealthColor(health);
		
		float barWidth = 0.1f;
		float barHeight = player.getHeight();
		
		// Position on the left side of player
		float barX = x - sin - 0.2f;
		float barZ = z - cos - 0.2f;
		
		stack.push();
		Matrix4f matrix = stack.peek().getPositionMatrix();
		
		RenderSystem.setShader(GameRenderer::getPositionColorProgram);
		if (ClickGUI.antiAliasing.getValue()) {
			GL11.glEnable(GL13.GL_MULTISAMPLE);
		}
		GL11.glDepthFunc(GL11.GL_ALWAYS);
		RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
		RenderSystem.defaultBlendFunc();
		RenderSystem.enableBlend();
		
		// Black background bar (vertical)
		BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
		buffer.vertex(matrix, barX, y, barZ).color(0f, 0f, 0f, 0.8f);
		buffer.vertex(matrix, barX, y + barHeight, barZ).color(0f, 0f, 0f, 0.8f);
		buffer.vertex(matrix, barX + barWidth, y + barHeight, barZ).color(0f, 0f, 0f, 0.8f);
		buffer.vertex(matrix, barX + barWidth, y, barZ).color(0f, 0f, 0f, 0.8f);
		BufferRenderer.drawWithGlobalProgram(buffer.end());
		
		// Health bar (vertical, fills from bottom to top with gradient)
		float healthHeight = barHeight * healthPercentage;
		
		buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
		buffer.vertex(matrix, barX + 0.01f, y + 0.01f, barZ).color(healthColor.getRed() / 255f, healthColor.getGreen() / 255f, healthColor.getBlue() / 255f, 1f);
		buffer.vertex(matrix, barX + 0.01f, y + healthHeight - 0.01f, barZ).color(healthColor.getRed() / 255f, healthColor.getGreen() / 255f, healthColor.getBlue() / 255f, 1f);
		buffer.vertex(matrix, barX + barWidth - 0.01f, y + healthHeight - 0.01f, barZ).color(healthColor.getRed() / 255f, healthColor.getGreen() / 255f, healthColor.getBlue() / 255f, 1f);
		buffer.vertex(matrix, barX + barWidth - 0.01f, y + 0.01f, barZ).color(healthColor.getRed() / 255f, healthColor.getGreen() / 255f, healthColor.getBlue() / 255f, 1f);
		BufferRenderer.drawWithGlobalProgram(buffer.end());
		
		GL11.glDepthFunc(GL11.GL_LEQUAL);
		RenderSystem.disableBlend();
		if (ClickGUI.antiAliasing.getValue()) {
			GL11.glDisable(GL13.GL_MULTISAMPLE);
		}
		stack.pop();
	}
	
	private void renderCorners(PlayerEntity e, Color color, MatrixStack stack) {
		float red = color.brighter().getRed() / 255f;
		float green = color.brighter().getGreen() / 255f;
		float blue = color.brighter().getBlue() / 255f;
		float alpha = color.brighter().getAlpha() / 255f;

		Camera c = mc.gameRenderer.getCamera();
		Vec3d camPos = c.getPos();
		Vec3d start = e.getLerpedPos(RenderTickCounter.ONE.getTickDelta(true)).subtract(camPos);
		float x = (float) start.x;
		float y = (float) start.y;
		float z = (float) start.z;

		double r = Math.toRadians(-c.getYaw() + 90);
		float sin = (float) (Math.sin(r) * (e.getWidth() / 1.7));
		float cos = (float) (Math.cos(r) * (e.getWidth() / 1.7));
		float cornerLength = e.getHeight() * 0.25f;
		
		stack.push();
		Matrix4f matrix = stack.peek().getPositionMatrix();

		RenderSystem.setShader(GameRenderer::getPositionColorProgram);
		if (ClickGUI.antiAliasing.getValue()) {
			GL11.glEnable(GL13.GL_MULTISAMPLE);
			GL11.glEnable(GL11.GL_LINE_SMOOTH);
			GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST);
		}
		GL11.glDepthFunc(GL11.GL_ALWAYS);
		RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
		RenderSystem.defaultBlendFunc();
		RenderSystem.enableBlend();

		GL11.glLineWidth(width.getValueInt());
		BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES,
				VertexFormats.POSITION_COLOR);

		// Bottom corners
		// Bottom left corner
		buffer.vertex(matrix, x - sin, y, z - cos).color(red, green, blue, alpha);
		buffer.vertex(matrix, x - sin, y + cornerLength, z - cos).color(red, green, blue, alpha);
		buffer.vertex(matrix, x - sin, y, z - cos).color(red, green, blue, alpha);
		buffer.vertex(matrix, x + sin * 0.5f, y, z + cos * 0.5f).color(red, green, blue, alpha);
		
		// Bottom right corner
		buffer.vertex(matrix, x + sin, y, z + cos).color(red, green, blue, alpha);
		buffer.vertex(matrix, x + sin, y + cornerLength, z + cos).color(red, green, blue, alpha);
		buffer.vertex(matrix, x + sin, y, z + cos).color(red, green, blue, alpha);
		buffer.vertex(matrix, x - sin * 0.5f, y, z - cos * 0.5f).color(red, green, blue, alpha);
		
		// Top corners
		// Top left corner
		buffer.vertex(matrix, x - sin, y + e.getHeight(), z - cos).color(red, green, blue, alpha);
		buffer.vertex(matrix, x - sin, y + e.getHeight() - cornerLength, z - cos).color(red, green, blue, alpha);
		buffer.vertex(matrix, x - sin, y + e.getHeight(), z - cos).color(red, green, blue, alpha);
		buffer.vertex(matrix, x + sin * 0.5f, y + e.getHeight(), z + cos * 0.5f).color(red, green, blue, alpha);
		
		// Top right corner
		buffer.vertex(matrix, x + sin, y + e.getHeight(), z + cos).color(red, green, blue, alpha);
		buffer.vertex(matrix, x + sin, y + e.getHeight() - cornerLength, z + cos).color(red, green, blue, alpha);
		buffer.vertex(matrix, x + sin, y + e.getHeight(), z + cos).color(red, green, blue, alpha);
		buffer.vertex(matrix, x - sin * 0.5f, y + e.getHeight(), z - cos * 0.5f).color(red, green, blue, alpha);

		BufferRenderer.drawWithGlobalProgram(buffer.end());
		GL11.glDepthFunc(GL11.GL_LEQUAL);
		GL11.glLineWidth(1f);
		RenderSystem.disableBlend();
		if (ClickGUI.antiAliasing.getValue()) {
			GL11.glDisable(GL11.GL_LINE_SMOOTH);
			GL11.glDisable(GL13.GL_MULTISAMPLE);
		}
		stack.pop();
	}
	
	private Color getHealthColor(float health) {
		if (health >= 20f) {
			return new Color(0, 255, 0); // Green for 20+ HP
		} else if (health >= 10f) {
			return new Color(255, 255, 0); // Yellow for 10-20 HP
		} else if (health >= 5f) {
			return new Color(255, 165, 0); // Orange for 5-10 HP
		} else {
			return new Color(255, 0, 0); // Red for <5 HP
		}
	}

	private Color getColor(int alpha) {
		return new Color(red.getValueInt(), green.getValueInt(), blue.getValueInt(), alpha);
	}
}
