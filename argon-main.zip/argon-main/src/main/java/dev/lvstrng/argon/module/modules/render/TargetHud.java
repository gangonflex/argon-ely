package dev.lvstrng.argon.module.modules.render;

import dev.lvstrng.argon.event.events.HudListener;
import dev.lvstrng.argon.event.events.PacketSendListener;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

import java.awt.*;

public final class TargetHud extends Module implements HudListener, PacketSendListener {
	private final NumberSetting xCoord = new NumberSetting(EncryptedString.of("X"), 0, 1920, 500, 1);
	private final NumberSetting yCoord = new NumberSetting(EncryptedString.of("Y"), 0, 1080, 500, 1);
	private final BooleanSetting hudTimeout = new BooleanSetting(EncryptedString.of("Timeout"), true)
			.setDescription(EncryptedString.of("Target hud will disappear after 10 seconds"));
	
	// Background Settings
	private final NumberSetting bgR = new NumberSetting(EncryptedString.of("BG Red"), 0, 255, 0, 1);
	private final NumberSetting bgG = new NumberSetting(EncryptedString.of("BG Green"), 0, 255, 0, 1);
	private final NumberSetting bgB = new NumberSetting(EncryptedString.of("BG Blue"), 0, 255, 0, 1);
	private final NumberSetting bgOpacity = new NumberSetting(EncryptedString.of("BG Opacity"), 0, 255, 150, 1);
	
	// Health Bar Settings
	private final NumberSetting healthR = new NumberSetting(EncryptedString.of("Health Red"), 0, 255, 0, 1);
	private final NumberSetting healthG = new NumberSetting(EncryptedString.of("Health Green"), 0, 255, 255, 1);
	private final NumberSetting healthB = new NumberSetting(EncryptedString.of("Health Blue"), 0, 255, 0, 1);
	
	private long lastAttackTime = 0;
	public static float animation;
	private static final long timeout = 10000;

	public TargetHud() {
		super(EncryptedString.of("Target HUD"),
				EncryptedString.of("Gives you information about the enemy player"),
				-1,
				Category.RENDER);
		addSettings(xCoord, yCoord, hudTimeout, bgR, bgG, bgB, bgOpacity, healthR, healthG, healthB);
	}

	@Override
	public void onEnable() {
		eventManager.add(HudListener.class, this);
		eventManager.add(PacketSendListener.class, this);
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(HudListener.class, this);
		eventManager.remove(PacketSendListener.class, this);
		super.onDisable();
	}

	@Override
	public void onRenderHud(HudEvent event) {
		DrawContext context = event.context;

		int x = xCoord.getValueInt();
		int y = yCoord.getValueInt();

		RenderUtils.unscaledProjection();
		if ((!hudTimeout.getValue() || (System.currentTimeMillis() - lastAttackTime <= timeout)) &&
				mc.player.getAttacking() != null && mc.player.getAttacking() instanceof PlayerEntity player && player.isAlive()) {
			animation = RenderUtils.fast(animation, mc.player.getAttacking() instanceof PlayerEntity player1 && player1.isAlive() ? 0 : 1, 15f);

			PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(player.getUuid());
			float tx = (float) x;
			float ty = (float) y;
			MatrixStack matrixStack = context.getMatrices();
			float thetaRotation = 90 * animation;
			matrixStack.push();
			matrixStack.translate(tx, ty, 0);

			matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(thetaRotation));
			matrixStack.translate(-tx, -ty, 0);

			// Background color
			Color bgColor = new Color(bgR.getValueInt(), bgG.getValueInt(), bgB.getValueInt(), bgOpacity.getValueInt());
			Color healthColor = new Color(healthR.getValueInt(), healthG.getValueInt(), healthB.getValueInt());
			
			// Main background with rounded corners (wider)
			RenderUtils.renderRoundedQuad(context.getMatrices(), bgColor, x, y, x + 200, y + 50, 10, 10, 10, 10, 10);

			// Player head
			if (entry != null) {
				PlayerSkinDrawer.draw(context, entry.getSkinTextures().texture(), x + 5, y + 5, 40);
			}

			// Player name
			TextRenderer.drawString(player.getName().getString(), context, x + 50, y + 8, Color.WHITE.getRGB());

			// Health bar background (dark) - wider
			RenderUtils.renderRoundedQuad(context.getMatrices(), new Color(0, 0, 0, 150), x + 50, y + 25, x + 195, y + 35, 5, 5, 5, 5, 10);
			
			// Health bar (colored based on health) - wider
			float health = player.getHealth() + player.getAbsorptionAmount();
			float maxHealth = player.getMaxHealth();
			float healthPercentage = Math.min(health / maxHealth, 1.0f);
			int healthBarWidth = (int) (145 * healthPercentage);
			
			if (healthBarWidth > 0) {
				RenderUtils.renderRoundedQuad(context.getMatrices(), healthColor, x + 50, y + 25, x + 50 + healthBarWidth, y + 35, 5, 5, 5, 5, 10);
			}
			
			// Health text
			String healthText = String.format("%.1f", health);
			TextRenderer.drawString(healthText, context, x + 50, y + 38, Color.WHITE.getRGB());

			matrixStack.pop();
		} else {
			animation = RenderUtils.fast(animation, 1, 15f);
		}
		RenderUtils.scaledProjection();
	}

	@Override
	public void onPacketSend(PacketSendListener.PacketSendEvent event) {
		if (event.packet instanceof PlayerInteractEntityC2SPacket packet) {
			packet.handle(new PlayerInteractEntityC2SPacket.Handler() {
				@Override
				public void interact(Hand hand) {

				}

				@Override
				public void interactAt(Hand hand, Vec3d pos) {

				}

				@Override
				public void attack() {
					if (mc.targetedEntity instanceof PlayerEntity) {
						lastAttackTime = System.currentTimeMillis();
					}
				}
			});
		}
	}
}